=== Scisco ===
Requires at least: 5.0
Tested up to: 5.5
Requires PHP: 7.0
License: Envato Market
License URI: http://themeforest.net/licenses

Questions And Answers WordPress Theme

== Description ==
Help documentation: http://www.wp4life.com/online/scisco/index.html

== Changelog ==

= 1.0 =
* Initial Release
