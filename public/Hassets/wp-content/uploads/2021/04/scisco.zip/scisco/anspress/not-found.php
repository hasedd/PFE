<div class="alert alert-danger"><?php esc_html_e( 'Error 404', 'scisco' ); ?></div>
