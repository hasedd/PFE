<?php
/**
 * When visitor try to browse category page without setting query_var then
 * this is show.
 *
 * @link http://anspress.io
 * @since 4.0
 * @package AnsPress
 */

?>
<div class="alert alert-warning">
	<p><?php esc_html_e( 'No category is set!', 'scisco' ); ?></p>
</div>


